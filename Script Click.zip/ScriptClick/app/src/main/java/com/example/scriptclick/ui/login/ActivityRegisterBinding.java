package com.example.scriptclick.ui.login;

public class ActivityRegisterBinding {
}
